package com.tab;

import org.springframework.stereotype.Component;

import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.MessageListener;
import javax.jms.TextMessage;

/**
 * @author yufulong
 * @date 2019/8/21 20:49:07
 **/
@Component
public class MyMessageListener implements MessageListener {
    @Override
    public void onMessage(Message message) {
        if (message != null && message instanceof TextMessage) {
            try {
                System.out.println("【消费消息】： " + ((TextMessage)message).getText() );
            } catch (JMSException e) {
                e.printStackTrace();
            }
        }
    }
}
