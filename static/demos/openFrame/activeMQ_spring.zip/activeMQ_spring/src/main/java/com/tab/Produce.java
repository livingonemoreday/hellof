package com.tab;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.jms.core.JmsTemplate;
import org.springframework.stereotype.Service;

/**
 * 生产者
 *
 * @author yufulong
 * @date 2019/8/20 22:01:38
 **/
@Service
public class Produce {

    @Autowired
    private JmsTemplate jmsTemplate;

    public static void main(String[] args) {
        ApplicationContext ctx = new ClassPathXmlApplicationContext("application.xml");
        Produce produce = ctx.getBean(Produce.class);
        produce.jmsTemplate.send(session -> session.createTextMessage("问君能有几多愁"));
        System.out.println("【消息生成成功】：=================");
    }
}
