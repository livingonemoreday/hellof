package com.tab;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.jms.core.JmsTemplate;
import org.springframework.stereotype.Component;

/**
 * 消费者
 *
 * @author yufulong
 * @date 2019/8/20 22:15:23
 **/
@Component
public class consumer {

    @Autowired
    private JmsTemplate jmsTemplate;

    public static void main(String[] args) {
        ApplicationContext ctx = new ClassPathXmlApplicationContext("application.xml");
        consumer consumer = ctx.getBean(consumer.class);
        String msg = (String) consumer.jmsTemplate.receiveAndConvert();
        System.out.println("【消息消费成功】：" + msg);
    }
}
