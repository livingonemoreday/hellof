package com.tab.realms;

import org.apache.shiro.authc.*;
import org.apache.shiro.authz.AuthorizationInfo;
import org.apache.shiro.authz.SimpleAuthorizationInfo;
import org.apache.shiro.crypto.hash.SimpleHash;
import org.apache.shiro.realm.AuthorizingRealm;
import org.apache.shiro.subject.PrincipalCollection;
import org.apache.shiro.util.ByteSource;

import java.util.HashSet;
import java.util.Objects;
import java.util.Set;

/**
 * @author yufulong
 * @date 2019/3/15 22:10:48
 **/
public class ShiroRealm extends AuthorizingRealm {

    /*登陆认证*/
    @Override
    protected AuthenticationInfo doGetAuthenticationInfo(AuthenticationToken authenticationToken) throws AuthenticationException {
        System.out.println("shiroRealm——1:"+ authenticationToken.hashCode());
        /*接收的实参token即为controller传过来的UsernamePasswordToken*/
        //1.将该token转为UsernamePasswordToken
        UsernamePasswordToken usernamePasswordToken = (UsernamePasswordToken)authenticationToken;
        //2.从UsernamePasswordToken中获取username 进行相关校验
        String username = usernamePasswordToken.getUsername();
        //2.1.通过username从数据库中获取该用户信息
        if ("a".equals(username))
            throw new UnknownAccountException("用户不存在");
        if ("b".equals(username))
            throw new LockedAccountException("用户被锁定");

        //3.根据用户情况，构建AuthenticationInfo对象
        /*
        principal:认证的实体信息：比如根据该用户名从数据库获取的该用户实体，此处为了方便直接用username
        credentials：从数据库获取的该用户密码,此处为了方便设定：9527
        realmName：当前realm对象的name，直接调用getName()即可
        * */
       // SimpleAuthenticationInfo simpleAuthenticationInfo = new SimpleAuthenticationInfo(username, "9527", getName());
        /*因考虑到即使加密之后：如果密码相同，在数据库中加密后的密码也是一样的，为此：盐值加密。
          即盐将成为即使密码相同加密后也不同的关键，so.以username作为盐*/
        ByteSource credentialsSalt = ByteSource.Util.bytes(username);
        return new SimpleAuthenticationInfo(username, "ef9aeb399de01a66b35f82115bbec675", credentialsSalt, getName());
    }
    public static void main(String[] args) {
        /*加密*/
        /*MD5, 密码， 盐-用户名，加密次数
        * */
        System.out.println(new SimpleHash("MD5", "9527", ByteSource.Util.bytes("007"), 1024));
    }
    /*权限认证*/
    @Override
    protected AuthorizationInfo doGetAuthorizationInfo(PrincipalCollection principalCollection) {

        //1.获取登陆用户的信息
        Object primaryPrincipal = principalCollection.getPrimaryPrincipal();
        System.out.println("============================== " + primaryPrincipal);
        //2.登陆用户信息获取当前用户的角色或权限（可能查询数据库
        Set<String> roles = new HashSet<>();
        roles.add("007");
        if (Objects.equals("008", primaryPrincipal))
            roles.add("008");
        //3.创建simpleAuthorizationInfo对象，并设置roles属性
        return new SimpleAuthorizationInfo(roles);
    }
}
