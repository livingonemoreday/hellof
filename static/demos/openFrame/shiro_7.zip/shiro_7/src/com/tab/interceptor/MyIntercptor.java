package com.tab.interceptor;

import org.springframework.web.servlet.HandlerInterceptor;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * @packageName: com.tab
 * @description:
 * @company: com.yinhai
 * @author: yufulong
 * @date: 2019/3/18 9:59:56
 **/
public class MyIntercptor implements HandlerInterceptor {
    @Override
    public boolean preHandle(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse, Object o) throws Exception {
        System.out.println("myInterceptor's preHandle method...........................");
        return true;
    }

    @Override
    public void postHandle(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse, Object o, ModelAndView modelAndView) throws Exception {
        //modelAndView.setView("interceptor");
        //System.out.println(modelAndView.getView());
       /* modelAndView.setViewName("/interceptor");*/
        System.out.println("myInterceptor's postHandle method...........................");

    }

    @Override
    public void afterCompletion(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse, Object o, Exception e) throws Exception {
        System.out.println("myInterceptor's afterCompletion method...........................");

    }
}
