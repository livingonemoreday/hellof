package com.tab.filters;

import javax.servlet.*;
import java.io.IOException;

/**
 * @author yufulong
 * @date 2019/3/18 9:17:08
 **/
public class MyFilter implements Filter {
    @Override
    public void init(FilterConfig filterConfig) throws ServletException {
        System.out.println("myfilter's init method.....................");
    }

    @Override
    public void doFilter(ServletRequest servletRequest, ServletResponse servletResponse, FilterChain filterChain) throws IOException, ServletException {
        System.out.println(servletRequest);
    }

    @Override
    public void destroy() {

    }
}
