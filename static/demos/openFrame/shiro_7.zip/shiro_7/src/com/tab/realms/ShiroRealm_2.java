package com.tab.realms;

import org.apache.shiro.authc.*;
import org.apache.shiro.crypto.hash.SimpleHash;
import org.apache.shiro.realm.AuthenticatingRealm;
import org.apache.shiro.util.ByteSource;

/**
 * @packageName: com.tab
 * @description: SHA1加密
 * @company: com.yinhai
 * @author: yufulong
 * @date: 2019/3/15 22:10:48
 **/
public class ShiroRealm_2 extends AuthenticatingRealm {
    @Override
    protected AuthenticationInfo doGetAuthenticationInfo(AuthenticationToken authenticationToken) throws AuthenticationException {
        System.out.println("shiroRealm:——2"+ authenticationToken.hashCode());
        /*接收的实参token即为controller传过来的UsernamePasswordToken*/
        //1.将该token转为UsernamePasswordToken
        UsernamePasswordToken usernamePasswordToken = (UsernamePasswordToken)authenticationToken;
        //2.从UsernamePasswordToken中获取username 进行相关校验
        String username = usernamePasswordToken.getUsername();
        //2.1.通过username从数据库中获取该用户信息
        if ("a".equals(username))
            throw new UnknownAccountException("用户不存在");
        if ("b".equals(username))
            throw new LockedAccountException("用户被锁定");

        //3.根据用户情况，构建AuthenticationInfo对象
        /*
        principal:认证的实体信息：比如根据该用户名从数据库获取的该用户实体，此处为了方便直接用username
        credentials：从数据库获取的该用户密码,此处为了方便设定：9527
        realmName：当前realm对象的name，直接调用getName()即可
        * */
        // SimpleAuthenticationInfo simpleAuthenticationInfo = new SimpleAuthenticationInfo(username, "9527", getName
        // ());
        /*因考虑到即使加密之后：如果密码相同，在数据库中加密后的密码也是一样的，为此：盐值加密。
          即盐将成为即使密码相同加密后也不同的关键，so.以username作为盐*/
        ByteSource credentialsSalt = ByteSource.Util.bytes(username);
        return new SimpleAuthenticationInfo(username, "37b77452b64df196526abf367187cc1c402f2095", credentialsSalt, getName());
    }
    public static void main(String[] args) {
        /*加密*/
        /*SHA1, 密码， 盐-用户名，加密次数
        * */
        System.out.println(new SimpleHash("SHA1", "9528", ByteSource.Util.bytes("008"), 1024));
    }
}
