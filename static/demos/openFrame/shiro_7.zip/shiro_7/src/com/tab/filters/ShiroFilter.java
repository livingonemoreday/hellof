package com.tab.filters;

import java.util.LinkedHashMap;

/**
 * @author yufulong
 * @date 2019/3/17 10:09:28
 **/
public class ShiroFilter {

    public LinkedHashMap<String, String> build() {
        /*必须为LinkedHashMap对象：可查看ShiroFilterFactoryBean的setFilterChainDefinitionMap方法*/
        LinkedHashMap<String, String> linkedHashMap = new LinkedHashMap<>();
        /*此处访问数据库，获取相关权限放置该map即可*/
        linkedHashMap.put("/login.jsp", "anon");
        linkedHashMap.put("/shiro/login", "anon");
        linkedHashMap.put("/shiro/logout", "logout");
        /*需要认证并且具有相应角色*/
        linkedHashMap.put("/9527.jsp", "authc,roles[007]");
        linkedHashMap.put("/9528.jsp", "authc,roles[008]");
        /*记住我的页面，将cookie(CookieRememberMeManager)写入磁盘，有效期内可无需登录访问*/
        linkedHashMap.put("/rememberMe.jsp", "user");
        linkedHashMap.put("/**", "authc");
        return linkedHashMap;
    }
}
