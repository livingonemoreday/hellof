package com.tab.controller;

import org.apache.shiro.SecurityUtils;
import org.apache.shiro.authc.UsernamePasswordToken;
import org.apache.shiro.subject.Subject;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

/**
 * @author yufulong
 * @date 2019/3/16 13:38:15
 **/
@Controller
@RequestMapping("/shiro/")
public class ShiroController {

    @RequestMapping("login")
    public String login(@RequestParam("username")String username, @RequestParam("password")String password,
                        HttpServletResponse response, HttpServletRequest request) throws IOException {

        Subject currentUser = SecurityUtils.getSubject();
        if (!currentUser.isAuthenticated()) {
            UsernamePasswordToken token = new UsernamePasswordToken(username, password);
            /*记住我*/
            token.setRememberMe(true);
            try {
                System.out.println("controller:" + token.hashCode());
                currentUser.login(token);
            } catch (Exception e) {
                e.printStackTrace();
                response.sendRedirect(request.getServletContext().getContextPath()+"/login.jsp");
            }
        }
        return "succ";
    }
}
