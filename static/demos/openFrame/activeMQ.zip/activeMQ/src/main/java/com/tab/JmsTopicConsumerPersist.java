package com.tab;

import org.apache.activemq.ActiveMQConnectionFactory;

import javax.jms.*;
import java.io.IOException;

/**
 * 持久化主题订阅者
 * 消费者订阅主题后，若离线， 生产者发布主题后消费者再上线，可收到生产者之前所发送的主题（类比 微信公众号消息）
 * @author yufulong
 * @date 2019/8/18 21:40:30
 **/
public class JmsTopicConsumerPersist {

    private static final String DEFAULT_BROKER_BIND_URL = "tcp://192.168.75.103:61616";

    private static final String TOPIC_NAME = "topic_persist";


    public static void main(String[] args) throws JMSException, IOException {

        System.out.println("【订阅者===============】");
        //1.创建链接工厂
        ActiveMQConnectionFactory activeMQConnectionFactory = new ActiveMQConnectionFactory(DEFAULT_BROKER_BIND_URL);
        //2.通过链接工厂，获得链接
        Connection connection = activeMQConnectionFactory.createConnection();
        connection.setClientID("订阅者ID");
        //4.创建会话session
        Session session = connection.createSession(false, Session.AUTO_ACKNOWLEDGE);
        //5.创建目的地（队列？主题？）
        Topic topic = session.createTopic(TOPIC_NAME);
        //订阅主题
        TopicSubscriber durableSubscriber = session.createDurableSubscriber(topic, "备注，随便写");
        //3.启动
        connection.start();
        //接收消息： receive()，如果没有主题，会一直阻塞于此
        Message message = durableSubscriber.receive();
        while (message != null) {
            System.out.println("【收到持久化主题】：" + ((TextMessage)message).getText());
            //receive(1000L)，在1000L后仍无主题不会继续阻塞
            message = durableSubscriber.receive(1000L);
        }

        //8.关闭链接
        session.close();
        connection.close();
    }
}
