package com.tab;

import org.apache.activemq.ActiveMQConnectionFactory;

import javax.jms.*;
import java.io.IOException;

/**
 * 消费者
 *
 * @author yufulong
 * @date 2019/8/18 12:46:49
 **/
public class JmsConsumer {

    private static final String DEFAULT_BROKER_BIND_URL = "tcp://192.168.75.103:61616";

    private static final String QUEUE_NAME = "queue_01";

    public static void main(String[] args) throws JMSException, IOException {
        System.out.println("【消费者启动】");
        //1.创建链接工厂
        ActiveMQConnectionFactory activeMQConnectionFactory = new ActiveMQConnectionFactory(DEFAULT_BROKER_BIND_URL);
        //2.通过链接工厂，获得链接
        Connection connection = activeMQConnectionFactory.createConnection();
        //3.启动
        connection.start();
        //4.创建会话session
        //消费者开启事务，亦需手动提交，否则消息被消费，但却不出队
        //签收，若开启手动签收需，对每一条消息， 当然如果开启了事务并提交了，就相当于是自动签收了，
        //如果开启事务，未提交，即使开启手动签收并签收，消息也不会出队
        Session session = connection.createSession(false, Session.CLIENT_ACKNOWLEDGE);
        //5.创建目的地（队列？主题？）
        Queue queue = session.createQueue(QUEUE_NAME);

        //6.创建消费真
        MessageConsumer consumer = session.createConsumer(queue);
        //同步阻塞
        while (true) {
            //7.消费消息
            //receive()；没有消息会一直等待
            Message message = consumer.receive(1000L);
            if (message == null) {
                break;
            }
            if (message instanceof TextMessage) {
                System.out.println("【消费消息】:" + ((TextMessage)message).getText());
            }
            //手动签收
            message.acknowledge();
           /* TextMessage textMessage = (TextMessage)consumer.receive();
            if (textMessage == null) {
                break;
            }
            System.out.println("【消费消息】:" + textMessage.getText());*/
        }

      //通过监听的方式来消费消息
    /*    consumer.setMessageListener(message -> {
            try {
                TimeUnit.SECONDS.sleep(1);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            if (message != null && message instanceof TextMessage) {
                try {
                    TextMessage textMessage = (TextMessage)message;
                    System.out.println("【消费TEXT消息】:" + textMessage.getText());
                    System.out.println("【消息属性值】:" + textMessage.getStringProperty("xx"));
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
            if (message != null && message instanceof MapMessage) {
                try {
                    MapMessage mapMessage = (MapMessage)message;
                    System.out.println("【消费MAP消息】:" + mapMessage.getString("k"));
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });*/
        //提交后方能使消息出队
       // session.commit();
        //保证控制台不关闭
        //System.in.read();

        //8.关闭链接
        session.close();
        connection.close();
    }
}
