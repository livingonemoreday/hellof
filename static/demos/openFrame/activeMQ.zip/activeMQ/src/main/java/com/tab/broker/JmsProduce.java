package com.tab.broker;

import org.apache.activemq.ActiveMQConnectionFactory;

import javax.jms.*;
import java.util.stream.IntStream;

/**
 * 生产者
 *
 * @author yufulong
 * @date 2019/8/18 11:53:21
 **/
public class JmsProduce {

    private static final String DEFAULT_BROKER_BIND_URL = "tcp://localhost:61616";

    private static final String QUEUE_NAME = "queue_01";

    public static void main(String[] args) throws JMSException {
        //1.创建链接工厂
        ActiveMQConnectionFactory activeMQConnectionFactory = new ActiveMQConnectionFactory(DEFAULT_BROKER_BIND_URL);
        //2.通过链接工厂，获得链接
        Connection connection = activeMQConnectionFactory.createConnection();
        //3.启动
        connection.start();
        //4.创建会话session  (false, Session.AUTO_ACKNOWLEDGE) （事务， 签收-指消费者，生产者谈不上签收）
        //若生产者开启事务，则需要在session关闭前手动提交，方能时消息进入队列
        Session session = connection.createSession(true, Session.AUTO_ACKNOWLEDGE);
        //5.创建目的地（队列？主题？）
        Queue queue = session.createQueue(QUEUE_NAME);
        //6.创建消息生产者
        MessageProducer producer = session.createProducer(queue);
        //消息持久化设置
        producer.setDeliveryMode(DeliveryMode.PERSISTENT);
        IntStream.rangeClosed(0, 5).forEach(i -> {
            try {
                //7.创建消息
                TextMessage textMessage = session.createTextMessage("第" + i + "条消息");
                //消息属性
                textMessage.setStringProperty("xx", "心远地自偏");
                MapMessage mapMessage = session.createMapMessage();
                mapMessage.setString("k", "v" + i);
                //8.发送消息
                producer.send(textMessage);
                producer.send(mapMessage);
            } catch (JMSException e) {
                e.printStackTrace();
            }
        });
        //提交事务
        session.commit();
        /*
        try {
            session.commit();
        } catch (Exception e) {
            session.rollback();
        }
        */
        //9.关闭资源
        producer.close();
        session.close();
        connection.close();

        System.out.println("【发送成功】: ===============================");
    }
}
