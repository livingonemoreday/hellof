package com.tab;

import org.apache.activemq.ActiveMQConnectionFactory;

import javax.jms.*;
import java.io.IOException;

/**
 * 消费者——主题模式
 *
 * @author yufulong
 * @date 2019/8/18 12:46:49
 **/
public class JmsTopicConsumer {

    private static final String DEFAULT_BROKER_BIND_URL = "tcp://192.168.75.103:61616";

    private static final String TOPIC_NAME = "topic_01";


    public static void main(String[] args) throws JMSException, IOException {

        System.out.println();
        //1.创建链接工厂
        ActiveMQConnectionFactory activeMQConnectionFactory = new ActiveMQConnectionFactory(DEFAULT_BROKER_BIND_URL);
        //2.通过链接工厂，获得链接
        Connection connection = activeMQConnectionFactory.createConnection();
        //3.启动
        connection.start();
        //4.创建会话session
        Session session = connection.createSession(false, Session.AUTO_ACKNOWLEDGE);
        //5.创建目的地（队列？主题？）
        Topic topic = session.createTopic(TOPIC_NAME);

        //6.创建消费真
        MessageConsumer consumer = session.createConsumer(topic);

      //通过监听的方式来消费消息
        consumer.setMessageListener(message -> {
            if (message != null && message instanceof TextMessage) {
                try {
                    TextMessage textMessage = (TextMessage)message;
                    System.out.println("【消费TOPIC消息】:" + textMessage.getText());
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
        //保证控制台不关闭
        System.in.read();

        //8.关闭链接
        session.close();
        connection.close();
    }
}
