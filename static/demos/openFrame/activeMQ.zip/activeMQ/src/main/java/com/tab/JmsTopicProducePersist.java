package com.tab;

import org.apache.activemq.ActiveMQConnectionFactory;

import javax.jms.*;
import java.util.stream.IntStream;

/**
 * 持久化主题生产者
 *
 * @author yufulong
 * @date 2019/8/18 21:39:38
 **/
public class JmsTopicProducePersist {

    private static final String DEFAULT_BROKER_BIND_URL = "tcp://192.168.75.103:61616";

    private static final String TOPIC_NAME = "topic_persist";

    public static void main(String[] args) throws JMSException {
        //1.创建链接工厂
        ActiveMQConnectionFactory activeMQConnectionFactory = new ActiveMQConnectionFactory(DEFAULT_BROKER_BIND_URL);
        //2.通过链接工厂，获得链接
        Connection connection = activeMQConnectionFactory.createConnection();

        //4.创建会话session
        Session session = connection.createSession(false, Session.AUTO_ACKNOWLEDGE);
        //5.创建目的地（队列？主题？）
        Topic topic = session.createTopic(TOPIC_NAME);
        //6.创建消息生产者
        MessageProducer producer = session.createProducer(topic);
        //设置其生产的主题是持久化的，需在启动之前设置
        producer.setDeliveryMode(DeliveryMode.PERSISTENT);
        //3.启动
        connection.start();

        IntStream.rangeClosed(0, 5).forEach(i -> {
            try {
                //7.创建消息
                TextMessage textMessage = session.createTextMessage("第" + i + "条topic消息");
                //8.发送消息
                producer.send(textMessage);
            } catch (JMSException e) {
                e.printStackTrace();
            }
        });
        //9.关闭资源
        producer.close();
        session.close();
        connection.close();

        System.out.println("【发送成功】: ===============================");
    }
}
