package com.tab.broker;

import org.apache.activemq.broker.BrokerService;

/**
 * 嵌入式broker
 *
 * @author yufulong
 * @date 2019/8/20 19:51:16
 **/
public class EmbedBroder {

    public static void main(String[] args) throws Exception {
        BrokerService bs = new BrokerService();
        bs.setUseJmx(true);
        bs.addConnector("tcp://localhost:61616");
        bs.start();
    }
}
