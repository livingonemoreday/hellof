package com.tab.activemq;

import org.springframework.jms.annotation.JmsListener;
import org.springframework.stereotype.Component;

import javax.jms.JMSException;
import javax.jms.TextMessage;

/**
 * 主题——消费者
 *
 * @author yufulong
 * @date 2019/8/24 12:48:39
 **/
@Component
public class ConsumerTopic {


    @JmsListener(destination = "${myTopic}")
    public void receive(TextMessage textMessage) throws JMSException {
        System.out.println("【消费消息】：" + textMessage.getText());
    }
}
