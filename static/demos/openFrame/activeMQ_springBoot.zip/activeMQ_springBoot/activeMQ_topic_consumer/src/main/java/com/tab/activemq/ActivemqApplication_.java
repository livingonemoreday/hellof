package com.tab.activemq;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ActivemqApplication_ {

    public static void main(String[] args) {
        SpringApplication.run(ActivemqApplication_.class, args);
    }

}
