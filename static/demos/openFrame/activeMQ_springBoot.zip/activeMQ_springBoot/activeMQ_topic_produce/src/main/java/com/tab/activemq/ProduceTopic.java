package com.tab.activemq;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jms.core.JmsMessagingTemplate;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import javax.jms.Queue;
import javax.jms.Topic;

/**
 * 主题——生产者
 *
 * @author yufulong
 * @date 2019/8/24 11:40:53
 **/
@Component
public class ProduceTopic {

    @Autowired
    private JmsMessagingTemplate jmsMessagingTemplate;

    @Autowired
    private Topic myTopic;

    //触发投递
    public void produceMsg() {
        jmsMessagingTemplate.convertAndSend(myTopic, "【发送主题消息】：" + System.currentTimeMillis());
    }
    //间时定投
    @Scheduled(fixedDelay = 3000)
    public void produceMsgScheduled() {
        System.out.println("【间时定投】");
        jmsMessagingTemplate.convertAndSend(myTopic, "【发送主题消息】：" + System.currentTimeMillis());
    }
}
