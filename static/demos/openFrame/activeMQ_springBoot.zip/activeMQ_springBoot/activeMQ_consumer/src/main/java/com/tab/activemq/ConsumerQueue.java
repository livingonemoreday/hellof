package com.tab.activemq;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jms.annotation.JmsListener;
import org.springframework.jms.core.JmsMessagingTemplate;
import org.springframework.stereotype.Component;

import javax.jms.JMSException;
import javax.jms.Queue;
import javax.jms.TextMessage;

/**
 * 队列——消费者
 *
 * @author yufulong
 * @date 2019/8/24 12:48:39
 **/
@Component
public class ConsumerQueue {


    @JmsListener(destination = "${myqueue}")
    public void receive(TextMessage textMessage) throws JMSException {
        System.out.println("【消费消息】：" + textMessage.getText());
    }
}
