package com.tab.activemq;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jms.core.JmsMessagingTemplate;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import javax.jms.Queue;

/**
 * 队列——生产者
 *
 * @author yufulong
 * @date 2019/8/24 11:40:53
 **/
@Component
public class ProduceQueue {

    @Autowired
    private JmsMessagingTemplate jmsMessagingTemplate;

    @Autowired
    private Queue queue;

    //触发投递
    public void produceMsg() {
        jmsMessagingTemplate.convertAndSend(queue, "【发送消息】：" + System.currentTimeMillis());
    }
    //间时定投
    @Scheduled(fixedDelay = 3000)
    public void produceMsgScheduled() {
        System.out.println("【间时定投】");
        jmsMessagingTemplate.convertAndSend(queue, "【发送消息】：" + System.currentTimeMillis());
    }
}
